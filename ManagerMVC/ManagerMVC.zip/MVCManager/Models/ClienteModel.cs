﻿namespace MVCManager.Models
{
    public class ClienteModel
    {
        public int idCliente { get; set; }
        public string nombreContacto { get; set; }
        public string apellidoContacto { get; set; }
        public string telefono { get; set; }
        public int idTipoDocumento { get; set; }
        public string desTipoDocumento { get; set; }
        public string numeroDocumento { get; set; }
        public string razonSocial { get; set; }
        public string nombreComercial { get; set; }
        public string correo { get; set; }
        public string direccion { get; set; }

    }
    public class ApiResponseCliente
    {
        public List<ClienteModel> result { get; set; }
    }
}

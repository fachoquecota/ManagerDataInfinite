﻿namespace MVCManager.Models
{
    public class SizeResponse
    {
        public List<Size> products { get; set; }
    }

}

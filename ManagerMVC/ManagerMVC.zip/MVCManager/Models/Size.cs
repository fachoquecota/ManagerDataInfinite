﻿namespace MVCManager.Models
{
    public class Size
    {
        public int idSize { get; set; }
        public string descripcion { get; set; }
        public bool activo { get; set; }
    }

}

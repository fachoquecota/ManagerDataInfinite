﻿namespace MVCManager.Models
{
    public class CategoriaModel
    {
        public int idCategoria { get; set; }
        public string descripcion { get; set; }
    }
}

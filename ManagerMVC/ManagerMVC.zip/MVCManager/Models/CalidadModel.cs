﻿namespace MVCManager.Models
{
    public class CalidadModel
    {
        public int idCalidad { get; set; }
        public string descripcion { get; set; }
    }
}

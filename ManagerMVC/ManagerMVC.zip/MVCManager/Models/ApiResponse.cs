﻿namespace MVCManager.Models
{
    public class ApiResponse
    {
        public bool Result { get; set; }
        public string Message { get; set; }
    }
}

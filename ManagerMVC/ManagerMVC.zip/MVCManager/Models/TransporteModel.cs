﻿namespace MVCManager.Models
{
    public class TransporteModel
    {
        public int idEmpresaTranspte { get; set; }
        public string descripcion { get; set; }
        public string direccion { get; set; }

    }
}

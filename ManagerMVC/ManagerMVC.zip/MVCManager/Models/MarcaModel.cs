﻿namespace MVCManager.Models
{
    public class MarcaModel
    {
        public int idMarca { get; set; }
        public string descripcion { get; set; }

    }
}

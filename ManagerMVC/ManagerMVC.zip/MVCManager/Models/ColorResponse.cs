﻿namespace MVCManager.Models
{
    public class ColorResponse
    {
        public List<Color> products { get; set; }
    }
}

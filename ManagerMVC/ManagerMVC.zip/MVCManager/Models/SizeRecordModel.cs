﻿namespace MVCManager.Models
{
    public class SizeRecordModel
    {
        public string IdSizeDetalle { get; set; }
        public string IdSize { get; set; }
        public bool Activo { get; set; }
    }
}
